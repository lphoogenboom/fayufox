# fayufox
Firefox plugin Including the whole Ayu colour scheme set and cosmetic improvements to browser.

## Installation
In order to install Fayufox you need to follow a few simple steps:
- Browser Setup
    - In Firefox enter `about:config` in your URL bar and hit enter
    - In the searchbar on this page enter `toolkit.legacyUserProfileCustomizations.stylesheets`
    - toggle this setting to `true` on the right
    - (Optional) for a better look of the browser:
        - toggle `browser.compactmode.show` to true aswell

- Installing Extension
    - Clone/download this repository
    - Further Instructions await....
